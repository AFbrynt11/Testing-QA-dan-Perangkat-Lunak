<?php
echo password_hash("1", PASSWORD_DEFAULT);
?>