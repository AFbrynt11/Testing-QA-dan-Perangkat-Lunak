<?php
    session_start();

    if(isset($_SESSION["is_login"])) {
        header("location: page/beranda.php");
    }
?>

<?php if (isset($_GET['error'])) { ?>
<script>
    alert("Username, password, atau role tidak sesuai ❗");
</script>
<?php } ?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>

    <!-- img -->
    <link rel="icon" href="/APLIKASIKU.COM/img/izin.png">

    <!-- my style -->
    <link rel="stylesheet" href="style/style.css">

    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">
    </head>
    <body>
        <?php include "/layout/header.php" ?>
        
        <div class="container-index">
            <div class="kiri">
                <div class="login-register-box">
                    <a href="index.php">
                        <img src="img/assets/home.svg" alt="" class="icon">
                    </a>
                    <h1 class="text-outline">LOGIN</h1>
                    <form method="POST" action="proses/plogin.php">       
                        Username:<br>
                        <input class="input" type="text" name="username" required=""><br><br>

                        Password:<br>
                        <input class="input" type="password" name="password" required=""><br><br>

                        Sebagai:<br>
                        <select class="input" name="role">
                            <option value="">-- Pilih --</option>
                            <option value="Petugas">Petugas</option>
                            <option value="Penduduk">Penduduk</option>
                        </select><br><br>

                        <button class="input" type="submit" name="login">Login</button><br>
                        <h2 class="text-outline">Belum punya akun? 
                            <a href="register.php">Daftar dulu</a>
                        </h2> 
                    </form>
                </div>
            </div>
        </div>
        
        <?php include "/layout/footer.php" ?>
    </body>
</html>