<?php
    include "../service/koneksi.php";

    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $tgl = $_POST['tgl'];
    $tempat = $_POST['tempat'];
    $alamat = $_POST['alamat'];
    $RT = $_POST['RT'];
    $RW = $_POST['RW'];

    $aksi = empty($_POST['aksi']) ? '' : $_POST['aksi'];

            // proses simpan
            if ($aksi == "PROSES") { 
        
                $sql = "INSERT INTO penduduk (nik, nama, jk, tgl, tempat, alamat, RT, RW)
                        VALUES ('$nik', '$nama', '$jk', '$tgl', '$tempat', '$alamat', '$RT', '$RW')";
                if (mysqli_query($db, $sql)) {
                    header("Location: ../page/penduduk.php?status=sukses");
                    echo "<script>alert('Data berhasil disimpan');</script>";
                    exit();
                } else {
                    echo "Error: " . mysqli_error($db);
                }
            // proses hapus   
            } else if ($aksi == "HAPUS") {
                $nik = $_POST['nik'];
            
                $sql = "DELETE FROM penduduk WHERE nik='$nik'";
                if (mysqli_query($db, $sql)) {
                    header("Location: ../page/penduduk.php?status=sukses");
                    exit();
                } else {
                    echo "Error: " . mysqli_error($db);
                }
            // proses update  
            } else if ($aksi == "UPDATE") { 
                $nik = $_POST['nik'];
                $nama = $_POST['nama'];
                $jk = $_POST['jk'];
                $tgl = $_POST['tgl'];
                $tempat = $_POST['tempat'];
                $alamat = $_POST['alamat'];
                $RT = $_POST['RT'];
                $RW = $_POST['RW'];
            
                $sql = "UPDATE penduduk set 
                            nama = '$nama',
                            jk = '$jk',
                            tgl = '$tgl',
                            tempat = '$tempat',
                            alamat = '$alamat',
                            RT = '$RT',
                            RW = '$RW'
                        WHERE nik = '$nik'";
                if (mysqli_query($db, $sql)) {
                    header("Location: ../page/penduduk.php?status=sukses");
                    exit();
                } else {
                    echo "Error: " . mysqli_error($db);
                } 
            }
?>