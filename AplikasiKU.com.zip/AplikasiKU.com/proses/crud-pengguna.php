<?php 
    include "../service/koneksi.php";

    $aksi     = isset($_POST['aksi']) ? $_POST['aksi'] : '';
    $id       = isset($_POST['id']) ? $_POST['id'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $role     = isset($_POST['role']) ? $_POST['role'] : '';

    if ($aksi == '') {
        header("Location: ../page/pengguna.php");
        exit();
    }

    // HAPUS
    if ($aksi == "HAPUS") {

        $sql = "DELETE FROM pengguna WHERE id='$id'";
        mysqli_query($db, $sql);
        header("Location: ../page/pengguna.php");
        exit();

    // UPDATE
    } elseif ($aksi == "UPDATE") {

        if ($password != '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE pengguna 
                    SET username='$username', role='$role', password='$hash'
                    WHERE id='$id'";
        } else {
            $sql = "UPDATE pengguna 
                    SET username='$username', role='$role'
                    WHERE id='$id'";
        }

        mysqli_query($db, $sql);
        header("Location: ../page/pengguna.php");
        exit();
    }
?>
