<?php
    include "../service/koneksi.php";
    session_start();

    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role     = $_POST['role'];

        $sql = "SELECT * FROM pengguna WHERE username='$username' AND role='$role'";
        $result = $db->query($sql);

        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();

            if (password_verify($password, $data['password'])) {
                $_SESSION["username"] = $data["username"];
                $_SESSION["role"] = $data["role"];

                echo "<script>
                        alert('Login berhasil ✅');
                        window.location.href = '../page/beranda.php';
                    </script>";
                exit;
            }
        }

        header("location: ../login.php?error=gagal");
        exit;
    }
?>
