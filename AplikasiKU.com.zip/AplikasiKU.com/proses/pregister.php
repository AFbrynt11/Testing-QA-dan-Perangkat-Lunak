<?php
    include "../service/koneksi.php";
    session_start();

    if (isset($_POST["register"])) {
        $username = trim($_POST["username"]);
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $role     = $_POST["role"];
    
        if ($username == "" || $password == "" || $role == "") {
        } else {
            $stmt = $db->prepare(
                "INSERT INTO pengguna (username, password, role) VALUES (?, ?, ?)"
            );
            $stmt->bind_param("sss", $username, $password, $role);
    
            if ($stmt->execute()) {
                header("Location: ../login.php?register=success");
                exit;
            } 
            $stmt->close();
        }
    }    
?>
