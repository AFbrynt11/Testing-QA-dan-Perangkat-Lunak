<?php
session_start();

include "../service/koneksi.php";

// proses cari
if (isset($_POST['aksi']) && $_POST['aksi'] == "CARI") {
    $username = trim($_POST['username']);
    if ($username != "") {
        $sql = "SELECT * FROM pengguna WHERE username LIKE '%$username%'";
    } else {
        $sql = "SELECT * FROM pengguna";
    }
} else {
    $sql = "SELECT * FROM pengguna";
}

$query = mysqli_query($db, $sql);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Data Pengguna</title>
            <!-- img -->
            <link rel="icon" href="../img/izin.png">

            <!-- my style -->
            <link rel="stylesheet" href="../style/style1.css">

            <!-- font google -->
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">
    </head>
    <body>
    <script src="../script/script1.js" defer></script>
        <nav id="sidebar">
            <ul>
                <li>
                    <span class="logo">APDAK</span>
                    <button onclick=toggleSidebar() id="toggle-btn">
                    <img src="../img/assets/bansowa.svg">
                    </button>
                </li>
                <li>
                    <a href="beranda.php">
                        <img src="../img/assets/dashboard.svg">
                        <span>Beranda</span>
                    </a>
                </li>
                <li>
                    <a href="pengguna.php">
                        <img src="../img/assets/user.svg">
                        <span>Data Pengguna</span>
                    </a>
                </li>
                <li>
                    <a href="penduduk.php">
                        <img src="../img/assets/Data Penduduk.svg">
                        <span>Data Penduduk</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <img src="../img/assets/Laporan.svg">
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="divider">
                    <a href="../logout.php">
                        <img src="../img/assets/logout.svg">
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <main>
            <div class="container">
                <h3>Data Pengguna</h3>
                <hr>
                <form action="../proses/crud-pengguna.php" method="POST">
                    <b>ID:</b><br>
                    <input class="input" type="number" name="id"><br><br>

                    <b>Username baru:</b><br>
                    <input class="input" type="text" name="username"><br><br>

                    <b>Password Baru:</b><br>
                    <input class="input" type="text" name="password"><br><br>

                    <b>Role:</b>
                    <select class="input" name="role">
                        <option value="petugas">Petugas</option>
                        <option value="penduduk">Penduduk</option>
                    </select>
                    <br>
                    <br>

                    <center>
                        <button class="submit" type="submit" name="aksi" value="UPDATE"
                            onclick="alert('User berhasil diubah ✅')">UBAH
                        </button>
                        <button class="submit" type="submit" name="aksi" value="HAPUS"
                            onclick="return confirm('Yakin hapus user ini ❓')">HAPUS
                        </button>
                    </center>
                </form>
                <br>
                <hr>
                <br>
                <form class="right" method="POST">
                    <input class="input" type="text" name="username" placeholder="Cari username...">
                    <button class="input" type="submit" name="aksi" value="CARI">CARI</button>
                </form>
                <table class="tabel">
                    <tr>
                        <th>ID</th>
                        <th>USERNAME</th>
                        <th>PASSWORD</th>
                        <th>ROLE</th>
                        <th>WAKTU DIBUAT</th>
                    </tr>

                    <!-- Tampilkan data -->
                    <?php while ($data = mysqli_fetch_assoc($query)) { ?>
                    <tr>
                        <td><?= $data['id'] ?></td>
                        <td><?= $data['username'] ?></td>
                        <td><?= $data['password'] ?></td>
                        <td><?= $data['role'] ?></td>
                        <td><?= $data['waktu'] ?></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </main>
    </body>
</html>