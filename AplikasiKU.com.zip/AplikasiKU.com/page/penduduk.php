<?php
    include "../service/koneksi.php";

    $query = mysqli_query($db, "SELECT * FROM penduduk");

    if (isset($_POST['aksi']) && $_POST['aksi'] == "CARI") {
        $nama = trim($_POST['nama']);
        if ($nama != "") {
            $sql = "SELECT * FROM penduduk WHERE nama LIKE '%$nama%'";
        } else {
            $sql = "SELECT * FROM penduduk";
        }
    } else {
        // tampilkan semua
        $sql = "SELECT * FROM penduduk";
    }

    $query = mysqli_query($db, $sql);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Data Penduduk</title>
        
        <!-- img -->
        <link rel="icon" href="/APLIKASIKU.COM/img/izin.png">

        <!-- my style -->
        <link rel="stylesheet" href="../style/style1.css">

        <!-- font google -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">

    </head>
    <script>
        function setAksi(val) {
            document.getElementById("aksi").value = val;
        }          
    </script>
    <body>

    <script src="../script/script1.js" defer></script>

    <nav id="sidebar">
            <ul>
                <li>
                    <span class="logo">APDAK</span>
                    <button onclick=toggleSidebar() id="toggle-btn">
                    <img src="../img/assets/bansowa.svg">
                    </button>
                </li>
                <li>
                    <a href="beranda.php">
                        <img src="../img/assets/dashboard.svg">
                        <span>Beranda</span>
                    </a>
                </li>
                <li>
                    <a href="pengguna.php">
                        <img src="../img/assets/user.svg">
                        <span>Data Pengguna</span>
                    </a>
                </li>
                <li>
                    <a href="penduduk.php">
                        <img src="../img/assets/Data Penduduk.svg">
                        <span>Data Penduduk</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <img src="../img/assets/Laporan.svg">
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="divider">
                    <a href="../logout.php">
                        <img src="../img/assets/logout.svg">
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <main>
            <div class="container">
                <h3>Data Penduduk</h3>
                <hr>
                <center>
                    <h3>Silahkan Masukkan Data Penduduk</h3>
                </center>
                    <form action="../proses/crud-penduduk.php" method="POST" >
                        <b>NIK:</b><br>
                        <input class="input" type="text" name="nik"><br><br>

                        <b>Nama:</b><br>
                        <input class="input" type="text" name="nama" placeholder="Nama Lengkap"><br><br>

                        <b>Jenis Kelamin:</b><br>
                        <select class="input" name="jk">
                            <option value="">-- Pilih --</option>
                            <option value="Laki-laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select><br><br>

                        <b>Tanggal Lahir:</b><br>
                        <input class="input" type="date" name="tgl"><br><br>

                        <b>Tempat Lahir:</b><br>
                        <input class="input" type="text" name="tempat"><br><br>

                        <b>Alamat:</b><br>
                        <textarea class="input" name="alamat" rows="4" cols="30"></textarea><br><br>

                        <b>RT:</b><br>
                        <input class="input" type="number" name="RT" min="1" max="5"><br><br>

                        <b>RW:</b><br>
                        <input class="input" type="number" name="RW" min="1" max="4"><br><br>
                            
                        <input type="hidden" name="aksi" id="aksi">

                        <center>
                            <button class="submit" type="submit" name="aksi" value="PROSES"
                                onclick=" alert('Data berhasil tersimpan ✅')">SIMPAN
                            </button>
                            <button class="submit" type="submit" name="aksi" value="UPDATE"
                                onclick=" alert('Data berhasil diubah ✅ ')">UBAH
                            </button>
                            <button class="submit" type="submit" name="aksi" value="HAPUS"
                                onclick="return confirm('Yakin hapus user ini ❓')">HAPUS
                            </button>
                        </center>
                    </form>
                <br>
                <hr>
                <br>
                <form class="right" action="penduduk.php" method="POST">
                    <input class="input" type="text" name="nama" placeholder="Cari nama...">
                    <input type="hidden" name="aksi" value="CARI">
                    <button class="input" type="submit">CARI</button>   
                </form>

                <table class="tabel">
                        <tr>
                            <th>ID</th>
                            <th>NIK</th>
                            <th>NAMA</th>
                            <th>JENIS KELAMIN</th>
                            <th>TANGGAL LAHIR</th>
                            <th>TEMPAT LAHIR</th>
                            <th>ALAMAT</th>
                            <th>RT</th>
                            <th>RW</th>
                        </tr>

                    <?php

                    // Tampilkan Data
                    while ($data = mysqli_fetch_array($query)) {
                        echo "<tr>
                                <td>$data[id]</td>
                                <td>$data[nik]</td>
                                <td>$data[nama]</td>
                                <td>$data[jk]</td>
                                <td>$data[tgl]</td>
                                <td>$data[tempat]</td>
                                <td>$data[alamat]</td>
                                <td>$data[RT]</td>
                                <td>$data[RW]</td>
                            </tr>";
                    }
                    ?>
                </table>
            </div>
        </main>
    </body>
</html>