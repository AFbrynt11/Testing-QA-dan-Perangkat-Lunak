<?php
    session_start();
    
    include "../service/koneksi.php";

    if (!isset($_SESSION['role'])) {
        header("Location: ../login.php");
        exit;
    }
    

    $query = mysqli_query($db, "SELECT * FROM penduduk");

    if (isset($_POST['aksi']) && $_POST['aksi'] == "CARI") {
        $nama = trim($_POST['nama']);
        if ($nama != "") {
            $sql = "SELECT * FROM penduduk WHERE nama LIKE '%$nama%'";
        } else {
            $sql = "SELECT * FROM penduduk";
        }
    } else {
        // Tampilkan semua
        $sql = "SELECT * FROM penduduk";
    }

    $query = mysqli_query($db, $sql);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        
        <!-- img -->
        <link rel="icon" href="/APLIKASIKU.COM/img/izin.png">

        <!-- my style -->
        <link rel="stylesheet" href="../style/style1.css">

        <!-- font google -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">
    </head>
    <body>
    <script src="../script/script1.js" defer></script>
        <nav id="sidebar">
            <ul>
                <li>
                    <span class="logo">APDAK</span>
                    <button onclick=toggleSidebar() id="toggle-btn">
                    <img src="../img/assets/bansowa.svg">
                    </button>
                </li>
                <li>
                    <a href="beranda.php">
                        <img src="../img/assets/dashboard.svg">
                        <span>Beranda</span>
                    </a>
                </li>
                <?php if ($_SESSION['role'] == 'Petugas') { ?>
                <li>
                    <a href="pengguna.php">
                        <img src="../img/assets/user.svg">
                        <span>Data Pengguna</span>
                    </a>
                </li>
                <li>
                    <a href="penduduk.php">
                        <img src="../img/assets/Data Penduduk.svg">
                        <span>Data Penduduk</span>
                    </a>
                </li>
                <?php } ?>
                <li>
                    <a href="laporan.php">
                        <img src="../img/assets/Laporan.svg">
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="divider">
                    <a href="../logout.php">
                        <img src="../img/assets/logout.svg">
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <main>
            <div class="container">
            <h3>
                Selamat Datang <?= $_SESSION["username"] ?> 
                (<?= ucfirst($_SESSION["role"]) ?>)
            </h3>
                <hr>
                <br>
                <form class="right" action="beranda.php" method="POST">
                    <input class="input" type="text" name="nama" placeholder="Cari nama...">
                    <input type="hidden" name="aksi" value="CARI">
                    <button class="input" type="submit">CARI</button>   
                </form>

                <table class="tabel">
                        <tr>
                            <th>ID</th>
                            <th>NIK</th>
                            <th>NAMA</th>
                            <th>JENIS KELAMIN</th>
                            <th>TANGGAL LAHIR</th>
                            <th>TEMPAT LAHIR</th>
                            <th>ALAMAT</th>
                            <th>RT</th>
                            <th>RW</th>
                        </tr>

                    <?php

                    // Tampilkan Data
                    while ($data = mysqli_fetch_array($query)) {
                        echo "<tr>
                                <td>$data[id]</td>
                                <td>$data[nik]</td>
                                <td>$data[nama]</td>
                                <td>$data[jk]</td>
                                <td>$data[tgl]</td>
                                <td>$data[tempat]</td>
                                <td>$data[alamat]</td>
                                <td>$data[RT]</td>
                                <td>$data[RW]</td>
                            </tr>";
                    }
                    ?>
                </table>
            </div>
        </main>
    </body>
</html>
