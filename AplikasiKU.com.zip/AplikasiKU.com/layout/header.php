<header>
    <center class="text-outline">
        <h1>SELAMAT DATANG DI APLIKASI KEPENDUDUKAN</h1>
    </center>
</header>