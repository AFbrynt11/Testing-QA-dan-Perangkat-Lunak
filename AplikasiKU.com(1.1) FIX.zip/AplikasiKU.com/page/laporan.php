<?php
    session_start();
    include "../service/koneksi.php";

    if (!isset($_SESSION['role']) || $_SESSION['role'] != 'petugas') {
        header("Location: beranda.php");
        exit;
    }

    if (isset($_POST['simpan'])) {
        $pelapor    = $_POST['pelapor'];
        $keterangan = $_POST['keterangan'];

        mysqli_query($db,
            "INSERT INTO laporan (pelapor, keterangan, waktu_laporan)
            VALUES ('$pelapor', '$keterangan', NOW())"
        ) or die(mysqli_error($db));
 
        header("Location: laporan.php");
        exit;
    } 
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Laporan</title>
        
        <!-- img -->
        <link rel="icon" href="/APLIKASIKU.COM/img/izin.png">

        <!-- my style -->
        <link rel="stylesheet" href="../style/style1.css">

        <!-- font google -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">

    </head>
    <script>
        function setAksi(val) {
            document.getElementById("aksi").value = val;
        }          
    </script>
    <body>
    <script src="../script/script1.js" defer></script>
    <nav id="sidebar">
            <ul>
                <li>
                    <span class="logo">APDAK</span>
                    <button onclick=toggleSidebar() id="toggle-btn">
                    <img src="../img/assets/bansowa.svg">
                    </button>
                </li>
                <li>
                    <a href="beranda.php">
                        <img src="../img/assets/dashboard.svg">
                        <span>Beranda</span>
                    </a>
                </li>
                <li>
                    <a href="pengguna.php">
                        <img src="../img/assets/user.svg">
                        <span>Data Pengguna</span>
                    </a>
                </li>
                <li>
                    <a href="penduduk.php">
                        <img src="../img/assets/Data Penduduk.svg">
                        <span>Data Penduduk</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <img src="../img/assets/Laporan.svg">
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="divider">
                    <a href="../logout.php">
                        <img src="../img/assets/logout.svg">
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <main>
            <div class="container">
                <h3>Laporan</h3>
                <hr>
                <br>
                <form method="post">
                    <b>Dibuat Oleh:</b><br>
                    <input class="input" type="text" name="pelapor" required><br><br>

                    <b>Keterangan:</b><br>
                    <textarea class="input-textarea" name="keterangan" required></textarea><br><br>

                    <button class="submit" type="submit" name="simpan"
                            onclick="alert ('Laporan Berhasil Tersimpan ✅')">SIMPAN LAPORAN
                    </button>
                </form>
                <br>
                <hr>
                <br>
                <table class="tabel">
                    <tr>
                        <th>ID</th>
                        <th>Pelapor</th>
                        <th>Keterangan</th>
                        <th>Waktu</th>
                    </tr>

                    <?php
                    $data = mysqli_query($db, "SELECT * FROM laporan ORDER BY waktu_laporan ASC");
                    while($row = mysqli_fetch_assoc($data)) {
                    ?>
                    <tr>
                        <td><?= $row['id_laporan'] ?></td>
                        <td><?= $row['pelapor'] ?></td>
                        <td><?= $row['keterangan'] ?></td>
                        <td><?= $row['waktu_laporan'] ?></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </main>
    </body>
</html>