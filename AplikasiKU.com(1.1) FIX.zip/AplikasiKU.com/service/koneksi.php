<?php
$host = "localhost";
$user = "root";
$psw  = "";
$db   = "apdak";

$db = mysqli_connect($host, $user, $psw, $db);

if (!$db) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
//echo "Koneksi berhasil!";
?>
