<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <!-- img -->
    <link rel="icon" href="/APLIKASIKU.COM/img/izin.png">

    <!-- my style -->
    <link rel="stylesheet" href="style/style.css">

    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>
<body>
    <?php include "/layout/header.php" ?>

    <div class="box">
            <h1>Haloooooo!!!</h1>
            <p class="box">Aplikasi ini dibuat menggunakan bahasa pemrograman HTML & PHP</p>
    </div>

    <div class="log">
        <div class="box"> 
            <p>Punya Akun</p>
            <a href="/APLIKASIKU.COM/login.php">
                <button type="button">Login</button>
            </a>
        </div>
        
        <div class="box">     
            <p>Belum Punya Akun</p>
            <a href="/APLIKASIKU.COM/register.php">
                <button type="button">Register</button>
            </a>
        </div>
    </div>

    <?php include "/layout/footer.php" ?>
</body>
</html>