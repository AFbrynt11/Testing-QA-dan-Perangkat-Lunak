<footer>
    <div class="text-outline">
        <h1>
            &copy; <?php echo date("Y"); ?> <br> 
            Dibuat oleh <a href="https://www.instagram.com/ariandrafbrynt/" class="text-reset fw-bold">Ariandra Febriyanto</a>
        </h1>
    </div>

</footer>